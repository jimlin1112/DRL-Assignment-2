rsync html/*.html rcoulom@kimsufi2:web/kayufu.com/gogui
